NOTE: Interactive Plotly Graph only available when executing code

I have also attached the image of the graph in .png format in the zip folder.
